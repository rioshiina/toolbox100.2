# data
Caches game data queried from the DataCenter file. Accessible through `mod.game.data`. Has the following attributes:

# abnormalities
TODO

# items
TODO

# continents
TODO

# users
TODO
