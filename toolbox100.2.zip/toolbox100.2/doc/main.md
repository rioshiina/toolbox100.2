# TERA Toolbox Documentation
In the following, you will find a documentation of TERA Toolbox.

**Note that everything in here only applies to TERA Toolbox. Legacy versions/forks of Tera-Proxy typically have a severely reduced set of features offered to both users and developers.**

If you find any inconsistencies or if anything does not come across clearly, please provide a pull request or contact me on Discord.

## Overview
- [Module Development](mod/main.md)
- TBD
